package com.example.hujiangbo.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main2Activity extends AppCompatActivity implements View.OnClickListener {

    String end;

    int length;


    Button btn1=null;
    Button btn2=null;
    Button btn3=null;
    Button btn4=null;
    Button btn5=null;
    Button btn6=null;
    Button btn7=null;
    Button btn8=null;
    Button btn9=null;
    Button btn0=null;
    Button btns1=null;
    Button btns2=null;
    Button btns3=null;
    Button btns4=null;
    Button btns5=null;
    EditText Je1=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        btn0 = (Button) findViewById(R.id.btn0);
        btn1 = (Button) findViewById(R.id.btn1);
        btn2 = (Button) findViewById(R.id.btn2);
        btn3 = (Button) findViewById(R.id.btn3);
        btn4 = (Button) findViewById(R.id.btn4);
        btn5 = (Button) findViewById(R.id.btn5);
        btn6 = (Button) findViewById(R.id.btn6);
        btn7 = (Button) findViewById(R.id.btn7);
        btn8 = (Button) findViewById(R.id.btn8);
        btn9 = (Button) findViewById(R.id.btn9);
        btns1 = (Button) findViewById(R.id.btns1);
        btns2 = (Button) findViewById(R.id.btns2);
        btns3 = (Button) findViewById(R.id.btns3);
        btns4 = (Button) findViewById(R.id.btns4);
        btns5 = (Button) findViewById(R.id.btns5);
        Je1 = (EditText) findViewById(R.id.Je1);
        btn0.setOnClickListener(this);
        btn1.setOnClickListener( this);
        btn2.setOnClickListener( this);
        btn3.setOnClickListener( this);
        btn4.setOnClickListener( this);
        btn5.setOnClickListener( this);
        btn6.setOnClickListener( this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
        btns1.setOnClickListener(this);
        btns2.setOnClickListener(this);
        btns3.setOnClickListener(this);
        btns4.setOnClickListener(this);
        btns5.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn0: Je1.setText(Je1.getText() + "0");
                break;
            case R.id.btn1: Je1.setText(Je1.getText() + "1");
                 break;
            case R.id.btn2: Je1.setText(Je1.getText() + "2");
                break;
            case R.id.btn3: Je1.setText(Je1.getText() + "3");
                break;
            case R.id.btn4: Je1.setText(Je1.getText() + "4");
                break;
            case R.id.btn5: Je1.setText(Je1.getText() + "5");
                break;
            case R.id.btn6: Je1.setText(Je1.getText() + "6");
                break;
            case R.id.btn7: Je1.setText(Je1.getText() + "7");
                break;
            case R.id.btn8: Je1.setText(Je1.getText() + "8");
                break;
            case R.id.btn9: Je1.setText(Je1.getText() + "9");
                break;
            case R.id.btns1: Je1.setText(Je1.getText() +"-");
                length=Je1.getText().length();
                break;
            case R.id.btns2: Je1.setText(Je1.getText() +"+");
                length=Je1.getText().length();
                break;
            case R.id.btns3: Je1.setText(Je1.getText() +"*");
                length=Je1.getText().length();
                break;
            case R.id.btns4: Je1.setText(Je1.getText() +"/");
                length=Je1.getText().length();
                break;
            case R.id.btns5://等于清空
                Je1.setText(Je1.getText() +"=");
                end=Je1.getText().toString();
                Je1.setText("");
               int endq=Integer.parseInt(end.substring(0, length-1));
               int endh=Integer.parseInt(end.substring(length, end.indexOf("=")));
               String test=end.substring(length-1,length);
                Je1.setText(test);

                if(test.equals("+")){
                int  num=endh+endq;
                end=Integer.toString(num);
                Je1.setText(end);
                }
                if(test.equals("-")){
                    int  num=endq-endh;
                    end=Integer.toString(num);
                    Je1.setText(end);
                }
                if(test.equals("*")){
                    int  num=endh*endq;
                    end=Integer.toString(num);
                    Je1.setText(end);
                }
                if(test.equals("/")){
                    int  num=endq/endh;
                    end=Integer.toString(num);
                    Je1.setText(end);
                }
                break;

        }
    }
}

