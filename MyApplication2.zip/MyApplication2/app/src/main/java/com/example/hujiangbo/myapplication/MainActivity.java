package com.example.hujiangbo.myapplication;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button button1=null;
    EditText editText=null;
    EditText editText1=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = (EditText) findViewById(R.id.editText);
        editText1 = (EditText) findViewById(R.id.editText1);
        button1=(Button) findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {

                String key=editText.getText().toString();
                String key1=editText1.getText().toString();
                if(key.equals("")&&key1.equals("")){
                   AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                   builder.setTitle("提示");
                   builder.setMessage("登录成功");
                   builder.show();

                    /*跳转*/
                    Intent intent = new Intent();
                    intent.setClass(MainActivity.this, Main2Activity.class);
                    startActivity(intent);
                }
                else{
                   AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                   builder.setTitle("提示");
                   builder.setMessage("您的密码错误");
                   builder.show();
                }
                }


        });

    }
}

